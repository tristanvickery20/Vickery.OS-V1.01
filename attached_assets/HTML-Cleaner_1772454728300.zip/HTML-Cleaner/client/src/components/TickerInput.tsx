import { Plus, Minus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

interface TickerInputProps {
  value: number;
  onChange: (value: string) => void;
  min?: number;
  max?: number;
}

export function TickerInput({ value, onChange, min = 0, max = 999 }: TickerInputProps) {
  const increment = () => {
    if (value < max) {
      onChange((value + 1).toString());
    }
  };

  const decrement = () => {
    if (value > min) {
      onChange((value - 1).toString());
    }
  };

  return (
    <div className="flex items-center gap-2 bg-white border border-primary/20 rounded-xl p-1 h-12 w-full max-w-[200px] shadow-sm">
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className="h-10 w-10 rounded-lg hover:bg-primary/5 text-primary"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          decrement();
        }}
        disabled={value <= min}
      >
        <Minus className="h-4 w-4" />
      </Button>
      
      <div className="flex-1 text-center font-display font-bold text-lg select-none">
        {value}
      </div>

      <Button
        type="button"
        variant="ghost"
        size="icon"
        className="h-10 w-10 rounded-lg hover:bg-primary/5 text-primary"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          increment();
        }}
        disabled={value >= max}
      >
        <Plus className="h-4 w-4" />
      </Button>
    </div>
  );
}
