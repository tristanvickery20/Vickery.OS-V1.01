import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface ServiceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  selected?: boolean;
  onClick?: () => void;
}

export function ServiceCard({ title, description, icon, selected, onClick }: ServiceCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={cn(
        "cursor-pointer rounded-2xl p-6 border-2 transition-all duration-300 relative overflow-hidden group",
        selected
          ? "border-primary bg-primary/5 shadow-xl shadow-primary/10"
          : "border-border bg-card hover:border-primary/50 hover:shadow-lg"
      )}
    >
      <div className={cn(
        "absolute top-4 right-4 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors",
        selected ? "border-primary bg-primary text-white" : "border-muted-foreground/30"
      )}>
        {selected && <Check className="w-3.5 h-3.5" strokeWidth={3} />}
      </div>

      <div className={cn(
        "w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-colors",
        selected ? "bg-primary text-white" : "bg-muted text-muted-foreground group-hover:bg-primary/10 group-hover:text-primary"
      )}>
        {icon}
      </div>

      <h3 className="text-xl font-bold font-display text-foreground">{title}</h3>
      <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{description}</p>
    </motion.div>
  );
}
