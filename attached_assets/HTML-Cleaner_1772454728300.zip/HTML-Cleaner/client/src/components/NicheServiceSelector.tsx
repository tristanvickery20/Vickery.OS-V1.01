import { useState, useEffect } from "react";
import { type NicheService } from "@/hooks/use-quotes";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { TickerInput } from "@/components/TickerInput";
import { motion, AnimatePresence } from "framer-motion";

interface NicheServiceSelectorProps {
  service: NicheService;
  isSelected: boolean;
  onToggle: (checked: boolean) => void;
  onDynamicFactorChange: (factorIndex: number, value: string) => void;
  quantityValues: Record<string, number>; 
}

export function NicheServiceSelector({
  service,
  isSelected,
  onToggle,
  onDynamicFactorChange,
  quantityValues,
}: NicheServiceSelectorProps) {
  return (
    <div className={`
      border rounded-xl p-4 transition-all duration-300
      ${isSelected 
        ? "border-primary bg-primary/5 shadow-md" 
        : "border-border hover:border-primary/30"
      }
    `}>
      <div className="flex items-start gap-3">
        <Checkbox
          id={`service-${service.name}`}
          checked={isSelected}
          onCheckedChange={onToggle}
          className="mt-1 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
        />
        <div className="flex-1">
          <Label
            htmlFor={`service-${service.name}`}
            className="text-base font-semibold cursor-pointer select-none"
          >
            {service.name}
          </Label>
        </div>
      </div>

      <AnimatePresence>
        {isSelected && service.dynamicFactors.length > 0 && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="pt-4 mt-2 space-y-4 border-t border-primary/10">
              {service.dynamicFactors.map((factor, idx) => {
                const labelLower = factor.label.toLowerCase();
                const isYesNo = labelLower.includes("yes=1") || labelLower.includes("yes = 1") || labelLower.includes("(yes=1, no=0)");
                const valueKey = `${service.name}:${factor.label}`;
                const value = quantityValues[valueKey] || 0;

                return (
                  <div key={idx} className="space-y-2">
                    <Label className="text-sm text-foreground/80 font-medium">
                      {factor.label.replace(/\(yes=1, no=0\)/gi, "").replace(/yes=1, no=0/gi, "").replace(/yes\s*=\s*1,\s*no\s*=\s*0/gi, "").trim()}
                    </Label>
                    
                    {isYesNo ? (
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant={value === 1 ? "default" : "outline"}
                          size="sm"
                          className="flex-1 rounded-lg"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            onDynamicFactorChange(idx, "1");
                          }}
                        >
                          Yes
                        </Button>
                        <Button
                          type="button"
                          variant={value === 0 ? "default" : "outline"}
                          size="sm"
                          className="flex-1 rounded-lg"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            onDynamicFactorChange(idx, "0");
                          }}
                        >
                          No
                        </Button>
                      </div>
                    ) : (
                      <TickerInput
                        value={value}
                        onChange={(val) => onDynamicFactorChange(idx, val)}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
