import vickeryLogo from "@assets/IMG_8663_1768335923872.jpeg";
import { useEffect, useState } from "react";
import { usePricingData, type PricingData, type NicheService, useCreateQuote } from "@/hooks/use-quotes";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Home as HomeIcon, Building2, Calendar as CalendarIcon, ArrowRight, ArrowLeft, CheckCircle2, Check } from "lucide-react";
import { ServiceCard } from "@/components/ServiceCard";
import { NicheServiceSelector } from "@/components/NicheServiceSelector";
// import { PopupModal } from "react-calendly";
import { format } from "date-fns";
import { type InsertQuote } from "@shared/schema";

export default function Home() {
  const { mutateAsync: fetchPricing, isPending: isLoadingPricing } = usePricingData();
  const { mutateAsync: createQuote, isPending: isSubmitting } = useCreateQuote();
  const { toast } = useToast();

  const [pricingData, setPricingData] = useState<PricingData | null>(null);
  const [step, setStep] = useState(1);
  const [error, setError] = useState<string | null>(null);

  // Scroll to top on step change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [step]);

  // Form State
  const [serviceType, setServiceType] = useState<"Residential" | "Commercial" | null>(null);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [serviceDescription, setServiceDescription] = useState("");
  
  // Niche Services & Costs
  const [selectedNicheServices, setSelectedNicheServices] = useState<string[]>([]); // Service Names
  // Map of "ServiceName:FactorLabel" -> Quantity
  const [dynamicQuantities, setDynamicQuantities] = useState<Record<string, number>>({});
  
  const [totalCost, setTotalCost] = useState(0);

  // Calendly State
  const [isCalendlyOpen, setIsCalendlyOpen] = useState(false);
  const [preferredDate, setPreferredDate] = useState<string | null>(null);

  // Initial Fetch
  useEffect(() => {
    fetchPricing()
      .then(setPricingData)
      .catch((err) => setError(err.message));
  }, []);

  // Calculate Total Cost
  useEffect(() => {
    if (!pricingData || !serviceType || !pricingData[serviceType]) return;
    
    let cost = 0;
    
    // Iterate through all selected categories
    const categories = pricingData[serviceType].categories;
    Object.values(categories).forEach(cat => {
      cat.services.forEach(service => {
        if (selectedNicheServices.includes(service.name)) {
          cost += service.baseCost;
          
          // Add dynamic factors
          service.dynamicFactors.forEach(factor => {
            const key = `${service.name}:${factor.label}`;
            const qty = dynamicQuantities[key] || 0;
            cost += qty * factor.costPerUnit;
          });
        }
      });
    });

    setTotalCost(cost);
  }, [selectedNicheServices, dynamicQuantities, pricingData, serviceType]);


  const handleNext = () => {
    console.log("handleNext state:", { step, serviceType, selectedCategories });
    if (step === 1 && !serviceType) {
      toast({
        title: "Missing Information",
        description: "Please select a project type.",
        variant: "destructive"
      });
      return;
    }
    if (step === 2 && selectedCategories.length === 0) {
      toast({
        title: "Missing Information",
        description: "Please select at least one category.",
        variant: "destructive"
      });
      return;
    }
    setStep(s => s + 1);
  };

  const handleBack = () => setStep(s => s - 1);

  const handleSubmit = async () => {
    if (!preferredDate) {
      toast({
        title: "Date Required",
        description: "Please pick a preferred date for your service.",
        variant: "destructive"
      });
      return;
    }

    try {
      const payload: InsertQuote = {
        serviceType: serviceType!,
        serviceDescription,
        selectedCategories,
        selectedNicheServices: selectedNicheServices.map(name => {
            return {
                name,
                quantities: Object.entries(dynamicQuantities)
                    .filter(([k]) => k.startsWith(`${name}:`))
                    .reduce((acc, [k, v]) => ({ ...acc, [k.split(':')[1]]: v }), {})
            }
        }),
        estimatedCost: totalCost.toFixed(2),
        preferredDate: preferredDate,
      };

      await createQuote(payload);
      
      toast({
        title: "Quote Submitted!",
        description: "We've received your request and will contact you shortly.",
      });
      
      setStep(5); // Show success view
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit quote. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Loading State
  if (isLoadingPricing || !pricingData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto" />
          <h2 className="text-xl font-display font-medium text-muted-foreground">Loading pricing data...</h2>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center text-destructive">
        Error loading data: {error}
      </div>
    );
  }

  // --- RENDER HELPERS ---
  
  const currentServiceCategories = (serviceType && pricingData && pricingData[serviceType]) ? pricingData[serviceType].categories : {};
  console.log("Current State:", { serviceType, pricingData, currentServiceCategories });

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-blue-50/50 to-indigo-50/30">
      
      {/* Header / Hero */}
      <header className="bg-white/80 backdrop-blur-md border-b sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src={vickeryLogo} alt="Vickery Electric" className="h-12 w-auto object-contain" />
          </div>
          <div className="text-sm font-medium text-muted-foreground">
            Instant Estimate Calculator
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-4 text-foreground">
            Get your estimate <span className="text-gradient">instantly</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Select your service needs below and our smart calculator will generate a precise estimate for your project.
          </p>
        </div>

        <div className="flex justify-center mb-8">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground bg-white border px-4 py-2 rounded-full shadow-sm">
                <span className={step >= 1 ? "text-primary font-bold" : ""}>1. Type</span>
                <span className="text-border">/</span>
                <span className={step >= 2 ? "text-primary font-bold" : ""}>2. Categories</span>
                <span className="text-border">/</span>
                <span className={step >= 3 ? "text-primary font-bold" : ""}>3. Services</span>
                <span className="text-border">/</span>
                <span className={step >= 4 ? "text-primary font-bold" : ""}>4. Review</span>
                <span className="text-border">/</span>
                <span className={step >= 5 ? "text-primary font-bold" : ""}>5. Done</span>
            </div>
        </div>

        {/* STEP 5: SUCCESS */}
        {step === 5 ? (
            <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-3xl p-12 text-center shadow-xl border border-primary/10"
            >
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 className="w-10 h-10" />
                </div>
                <h2 className="text-3xl font-bold font-display text-foreground mb-4">Request Received!</h2>
                <p className="text-muted-foreground text-lg mb-8 max-w-md mx-auto">
                    Your estimated total is <strong className="text-foreground">${totalCost.toFixed(2)}</strong>. 
                    We have recorded your preferred appointment request.
                    Our team will review the details and reach out if we have questions.
                </p>
                <Button onClick={() => window.location.reload()} size="lg">Start New Quote</Button>
            </motion.div>
        ) : (
            
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Form Area */}
          <div className="lg:col-span-2 space-y-6">
            <AnimatePresence mode="wait">
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="space-y-8"
                >
                  <section>
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                        <span className="w-7 h-7 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm">1</span>
                        Project Type
                    </h2>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <ServiceCard
                        title="Residential"
                        description="Home electrical upgrades, repairs, and installations."
                        icon={<HomeIcon className="w-6 h-6" />}
                        selected={serviceType === "Residential"}
                        onClick={() => {
                            setServiceType("Residential");
                            setSelectedCategories([]); 
                            setSelectedNicheServices([]);
                        }}
                      />
                      <ServiceCard
                        title="Commercial"
                        description="Office, retail, and industrial electrical solutions."
                        icon={<Building2 className="w-6 h-6" />}
                        selected={serviceType === "Commercial"}
                        onClick={() => {
                            setServiceType("Commercial");
                            setSelectedCategories([]);
                            setSelectedNicheServices([]);
                        }}
                      />
                    </div>
                  </section>
                  
                  <div className="pt-6 border-t flex justify-end">
                    <Button onClick={handleNext} size="lg" className="gap-2 rounded-xl px-8 bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20">
                        Next Step <ArrowRight className="w-4 h-4" />
                    </Button>
                  </div>
                </motion.div>
              )}

              {step === 2 && serviceType && pricingData && pricingData[serviceType] && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8"
                >
                  <section>
                    <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                      <span className="w-7 h-7 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm">2</span>
                      Categories
                    </h2>
                    <div className="grid sm:grid-cols-2 gap-3">
                      {Object.keys(pricingData[serviceType].categories).map((catName) => (
                        <div 
                          key={catName}
                          data-testid={`category-${catName}`}
                          onClick={() => {
                              console.log("Clicking category:", catName);
                              setSelectedCategories(prev => {
                                  const next = prev.includes(catName) 
                                      ? prev.filter(c => c !== catName)
                                      : [...prev, catName];
                                  console.log("Updated categories:", next);
                                  return next;
                              });
                          }}
                          className={`
                              cursor-pointer px-4 py-3 rounded-xl border flex items-center justify-between transition-all select-none
                              ${selectedCategories.includes(catName)
                                  ? "bg-white border-primary shadow-sm"
                                  : "bg-white/50 border-transparent hover:bg-white hover:border-border"
                              }
                          `}
                        >
                          <span className="font-medium">{catName}</span>
                          {selectedCategories.includes(catName) && (
                              <Check className="w-4 h-4 text-primary" />
                          )}
                        </div>
                      ))}
                    </div>
                  </section>

                  <div className="pt-6 border-t flex justify-between">
                    <Button variant="ghost" onClick={handleBack} className="gap-2">
                        <ArrowLeft className="w-4 h-4" /> Back
                    </Button>
                    <Button onClick={handleNext} size="lg" className="gap-2 rounded-xl px-8 bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20">
                        Next Step <ArrowRight className="w-4 h-4" />
                    </Button>
                  </div>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8"
                >
                    <section>
                        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                            <span className="w-7 h-7 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm">3</span>
                            Select Specific Services
                        </h2>
                        <div className="space-y-8">
                            {selectedCategories.map(catName => {
                                const category = currentServiceCategories[catName];
                                if (!category) return null;
                                return (
                                    <div key={catName} className="bg-white/50 rounded-2xl p-6 border border-border/50">
                                        <h3 className="font-display font-bold text-lg text-primary mb-4">{catName}</h3>
                                        <div className="grid gap-4">
                                            {category.services.map(service => (
                                                <NicheServiceSelector
                                                    key={service.name}
                                                    service={service}
                                                    isSelected={selectedNicheServices.includes(service.name)}
                                                    onToggle={(checked) => {
                                                        setSelectedNicheServices(prev => 
                                                            checked 
                                                                ? [...prev, service.name]
                                                                : prev.filter(n => n !== service.name)
                                                        );
                                                    }}
                                                    quantityValues={dynamicQuantities}
                                                    onDynamicFactorChange={(idx, value) => {
                                                        const factor = service.dynamicFactors[idx];
                                                        const key = `${service.name}:${factor.label}`;
                                                        setDynamicQuantities(prev => ({
                                                            ...prev,
                                                            [key]: parseFloat(value) || 0
                                                        }));
                                                    }}
                                                />
                                            ))}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </section>

                    <div className="pt-6 border-t flex justify-between">
                        <Button variant="ghost" onClick={handleBack} className="gap-2">
                            <ArrowLeft className="w-4 h-4" /> Back
                        </Button>
                        <Button onClick={handleNext} size="lg" className="gap-2 rounded-xl px-8 bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20">
                            Next Step <ArrowRight className="w-4 h-4" />
                        </Button>
                    </div>
                </motion.div>
              )}

              {step === 4 && (
                <motion.div
                  key="step4"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8"
                >
                    <section className="bg-white/50 rounded-2xl p-6 border border-border/50 space-y-6">
                        <h2 className="text-xl font-bold flex items-center gap-2">
                            <span className="w-7 h-7 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm">4</span>
                            Final Review & Scheduling
                        </h2>
                        
                        <div className="grid gap-6">
                            <div className="space-y-2">
                                <Label className="text-sm font-medium text-muted-foreground">Preferred Appointment Date</Label>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <Button 
                                        variant="outline" 
                                        onClick={() => {
                                            const today = new Date().toISOString();
                                            setPreferredDate(today);
                                            toast({
                                                title: "Date Selected",
                                                description: "We've recorded your preference for today."
                                            });
                                        }}
                                        className={`justify-start text-left font-normal h-12 rounded-xl border-primary/20 hover:border-primary/40 bg-white ${preferredDate ? 'border-primary ring-1 ring-primary' : ''}`}
                                    >
                                        <CalendarIcon className="mr-2 h-4 w-4 text-primary" />
                                        {preferredDate ? format(new Date(preferredDate), "PPP") : "Select a date"}
                                    </Button>
                                    <div className="text-xs text-muted-foreground flex items-center">
                                        Note: We will confirm the exact time with you after review.
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label className="text-sm font-medium text-muted-foreground">Project Description</Label>
                                <Textarea 
                                    placeholder="Any additional details about your project..."
                                    className="bg-white border-primary/20 focus:border-primary shadow-sm min-h-[120px] resize-none text-base p-4 rounded-xl"
                                    value={serviceDescription}
                                    onChange={(e) => setServiceDescription(e.target.value)}
                                />
                            </div>

                            <div className="bg-foreground text-background rounded-2xl p-6 shadow-xl relative overflow-hidden">
                                <h3 className="text-lg font-medium text-white/60 mb-1">Final Estimated Cost</h3>
                                <div className="text-4xl font-display font-bold">
                                    ${totalCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                </div>
                                <p className="mt-4 text-sm text-white/40">
                                    Final pricing may vary based on on-site inspection.
                                </p>
                            </div>
                        </div>
                    </section>

                    <div className="pt-6 border-t flex justify-between">
                        <Button variant="ghost" onClick={handleBack} className="gap-2">
                            <ArrowLeft className="w-4 h-4" /> Back
                        </Button>
                        <Button 
                            onClick={handleSubmit} 
                            disabled={isSubmitting || totalCost === 0}
                            size="lg" 
                            className="gap-2 rounded-xl px-8 bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20"
                        >
                            {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Submit Request"}
                        </Button>
                    </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Sticky Estimate Panel */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-6">
                {step === 4 && (
                    <div className="bg-foreground text-background rounded-2xl p-6 shadow-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
                        
                        <h3 className="text-lg font-medium text-white/60 mb-1">Estimated Cost</h3>
                        <div className="text-4xl font-display font-bold mb-6">
                            ${totalCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>

                        <div className="space-y-4 pt-6 border-t border-white/10">
                            <div className="flex justify-between text-sm">
                                <span className="text-white/60">Service Type</span>
                                <span className="font-medium">{serviceType || "-"}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-white/60">Categories</span>
                                <span className="font-medium">{selectedCategories.length} selected</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-white/60">Date Request</span>
                                <span className="font-medium truncate max-w-[120px]">
                                    {preferredDate ? format(new Date(preferredDate), "MMM do") : "Not requested"}
                                </span>
                            </div>
                        </div>

                        <Button 
                            variant="outline" 
                            onClick={() => {
                                const today = new Date().toISOString();
                                setPreferredDate(today);
                                toast({
                                    title: "Date Selected",
                                    description: "We've recorded your preference for today."
                                });
                            }}
                            className="w-full mt-6 bg-white/10 border-white/20 hover:bg-white/20 text-white gap-2"
                        >
                            <CalendarIcon className="w-4 h-4" />
                            {preferredDate ? "Change Date" : "Pick a Date"}
                        </Button>
                    </div>
                )}
                
                <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 text-sm text-blue-800">
                    <p className="flex gap-2">
                        <span className="font-bold">Note:</span>
                        This is a rough estimate. Final pricing may vary based on on-site inspection.
                    </p>
                </div>
            </div>
          </div>
        </div>
        )}
      </main>

          {/* 
        <PopupModal
            url="https://calendly.com/"
            pageSettings={{
                backgroundColor: 'ffffff',
                hideEventTypeDetails: false,
                hideLandingPageDetails: false,
                primaryColor: '00a2ff',
                textColor: '4d5055'
            }}
            rootElement={document.getElementById("root")!}
            open={isCalendlyOpen}
            onModalClose={() => setIsCalendlyOpen(false)}
            onDateAndTimeSelected={(e) => {
                const payload = e as { date: string }; 
                const mockDate = new Date().toISOString();
                setPreferredDate(mockDate);
                setIsCalendlyOpen(false);
                toast({
                    title: "Date Selected",
                    description: "We've recorded your preferred appointment time."
                });
            }}
        /> 
        */}

    </div>
  );
}
