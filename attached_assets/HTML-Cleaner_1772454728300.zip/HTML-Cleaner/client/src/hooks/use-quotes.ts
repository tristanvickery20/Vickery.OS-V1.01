import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertQuote } from "@shared/routes";

// Hook to fetch pricing data from Google Sheets via elk.sh
// Data format is specific to the sheet structure
export interface PricingRow {
  "Service Type": string;
  Category: string;
  "Niche Service": string;
  "Base Cost": string; // Comes as string "$100" or similar
  dynamicLabel1?: string;
  costPerUnit1?: string;
  dynamicLabel2?: string;
  costPerUnit2?: string;
  dynamicLabel3?: string;
  costPerUnit3?: string;
  dynamicLabel4?: string;
  costPerUnit4?: string;
  dynamicLabel5?: string;
  costPerUnit5?: string;
}

export interface NicheService {
  name: string;
  baseCost: number;
  dynamicFactors: {
    label: string;
    costPerUnit: number;
  }[];
}

export interface Category {
  name: string;
  services: NicheService[];
}

export interface ServiceType {
  name: string; // Residential or Commercial
  categories: Record<string, Category>;
}

export type PricingData = Record<string, ServiceType>;

export function usePricingData() {
  const url = "https://opensheet.elk.sh/100cNwo9t-Xg2QOeVOI1Ma7s7rRxdqP2R4UgblU4z-Ow/Job%20Costing%20Data";

  return useMutation({
    mutationFn: async (): Promise<PricingData> => {
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch pricing data");
      const rows: PricingRow[] = await res.json();
      return processPricingData(rows);
    },
  });
}

function processPricingData(rows: any[]): PricingData {
  const data: PricingData = {};
  console.log("Raw rows from sheet:", rows);

  rows.forEach((row) => {
    // Access properties case-insensitively and handle both camelCase and Title Case
    const serviceType = (row["Service Type"] || row["serviceType"] || "").toLowerCase();
    const categoryName = row["Category"] || row["category"];
    const serviceName = row["Niche Service"] || row["nicheService"];
    
    if (!serviceType || !categoryName || !serviceName) {
      console.warn("Skipping row due to missing fields:", row);
      return;
    }

    // Standardize serviceType for internal lookup (Residential/Commercial)
    const standardizedType = serviceType.charAt(0).toUpperCase() + serviceType.slice(1);

    // Parse base cost
    const baseCostRaw = row["Base Cost"] || row["baseCost"] || "0";
    const baseCost = parseFloat(String(baseCostRaw).replace(/[^0-9.]/g, ""));

    if (!data[standardizedType]) {
      data[standardizedType] = { name: standardizedType, categories: {} };
    }

    if (!data[standardizedType].categories[categoryName]) {
      data[standardizedType].categories[categoryName] = { name: categoryName, services: [] };
    }

    // Process dynamic factors
    const dynamicFactors = [];
    for (let i = 1; i <= 5; i++) {
      const label = row[`dynamicLabel${i}`];
      const costStr = row[`costPerUnit${i}`];
      
      if (label && costStr) {
        const cost = parseFloat(String(costStr).replace(/[^0-9.]/g, ""));
        if (!isNaN(cost)) {
          dynamicFactors.push({ label, costPerUnit: cost });
        }
      }
    }

    data[standardizedType].categories[categoryName].services.push({
      name: serviceName,
      baseCost,
      dynamicFactors,
    });
  });

  console.log("Processed Pricing Data:", data);
  return data;
}

export function useCreateQuote() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: InsertQuote) => {
      const res = await fetch(api.quotes.create.path, {
        method: api.quotes.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        throw new Error("Failed to create quote");
      }

      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.quotes.list.path] });
    },
  });
}
