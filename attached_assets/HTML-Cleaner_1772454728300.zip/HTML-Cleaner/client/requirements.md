## Packages
framer-motion | Smooth transitions between form steps
react-calendly | Integration for the "Pick a time" calendar feature

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
