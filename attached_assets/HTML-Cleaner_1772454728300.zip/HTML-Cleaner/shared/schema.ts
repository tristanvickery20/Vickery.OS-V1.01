import { pgTable, text, serial, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const quotes = pgTable("quotes", {
  id: serial("id").primaryKey(),
  serviceType: text("service_type").notNull(),
  serviceDescription: text("service_description"),
  selectedCategories: jsonb("selected_categories").$type<string[]>(),
  selectedNicheServices: jsonb("selected_niche_services").$type<any[]>(),
  estimatedCost: text("estimated_cost"),
  preferredDate: text("preferred_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertQuoteSchema = createInsertSchema(quotes).omit({ 
  id: true, 
  createdAt: true 
});

export type InsertQuote = z.infer<typeof insertQuoteSchema>;
export type Quote = typeof quotes.$inferSelect;
